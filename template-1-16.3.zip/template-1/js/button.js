//TODO
//@media > 900px h-menu
//@media < 900ox v-menu
//js ako je ekran manji od 900 init
//ako nije nista
//eventListener za promenu velicine ekrana

let bars;
let x;
let menu;

let toggleDisplay = node =>
{
	if( node.style.display === "none" )
	{
		node.style.display = "block";
	}
	else
	{
		node.style.display = "none";
	}
}

let toggleMenu = () => 
{
	toggleDisplay( bars );
	toggleDisplay( x );
	toggleDisplay( menu );
}

let init = () =>
{
	bars = document.querySelector( ".bars" );
	x = document.querySelector( ".x" );
	menu = document.querySelector( ".v-menu" );

	//init nece moci na ovaj nacin, gasi h-menu
	//postoji li nacin da se ovo uradi pomocu klasa?
	menu.style.display = "none";
	bars.style.display = "block";
	x.style.display = "none";

	bars.addEventListener( "click", toggleMenu );
	x.addEventListener( "click", toggleMenu );
}

document.addEventListener( "DOMContentLoaded", init );
