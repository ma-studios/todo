class Product
{
	constructor( id, name, desc )
	{
		this.id = id;
		this.name = name;
		this.desc = desc;
	}

	log()
	{
		console.log( this.id, this.name, this.desc );
	}
}

const product_list = [];

const p1 = new Product( 1, "Proizvod 1", "..." );
const p2 = new Product( 2, "Proizvod 2", "..." );
const p3 = new Product( 3, "Proizvod 3", "..." );
const p4 = new Product( 4, "Test Proizvod", "Opis" );

product_list.push( p1 );
product_list.push( p2 );
product_list.push( p3 );
product_list.push( p4 );

export default product_list;

