import product_list from "./products.js";

class Cart
{
	constructor( product_list )
	{
		this.contents = [];
		product_list.map( ( product, i ) =>
			{
				this.contents[ i ] = 
					{
						product: product,
						amount: 0
					};
			}
		)
	}

	addProduct( product_id )
	{
		for( let i = 0; i < this.contents.length; i ++ )
		{
			if( this.contents[ i ].product.id === product_id )
			{
				this.contents[ i ].amount = this.contents[ i ].amount + 1;
				break;
			}
		}
	}

	removeProduct( product_id )
	{
		for( let i = 0; i < this.contents.length; i ++ )
		{
			if( this.contents[ i ].product.id === product_id )
			{
				this.contents[ i ].amount = this.contents[ i ].amount - 1;
				break;
			}
		}
	}
}

export default Cart;
