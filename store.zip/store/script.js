import product_list from "./products.js"; //export default product_list -> import
import Cart from "./cart.js";

const cart = new Cart( product_list );

let update_cart = () =>
{
	let cart_node = document.querySelector( ".cart" );
	let new_cart_node = generate_cart_element();

	cart_node.replaceWith( new_cart_node );
}

let on_remove_click = ( product_id ) =>
{//vrh skoupa u kod su definisane
	cart.removeProduct( product_id );
	update_cart();
}

let generate_cart_element = () =>
{
	let cart_node = document.createElement( "div" );
	cart_node.classList.add( "cart" );

	cart.contents.map( content_obj =>
		{
			const product = content_obj.product;
			const amount = content_obj.amount;

			//ako ime 0 proizvoda u korpi, kraj, ne idi dalje
			if( amount === 0 )
			{
				return;
			}
			//ako ima vise od 0 tog proizvoda u korpi, hocu da generisem rep. za taj proivod

			let product_node = document.createElement( "div" ); //kontejner za razlicite stavke( ime/kol/dugme )
			product_node.classList.add( "cart_product" );

			let amount_node = document.createElement( "div" );
			amount_node.innerHTML = amount;

			let product_name = document.createElement( "div" );
			product_name.innerHTML = product.name;

			let remove_button = document.createElement( "div" );
			remove_button.classList.add( "remove-button" );
			remove_button.addEventListener( "click", () => on_remove_click( product.id ) );

			product_node.appendChild( product_name ); //pod komenponenete dodao u kontejner
			product_node.appendChild( amount_node );
			product_node.appendChild( remove_button );

			cart_node.appendChild( product_node ); //kontejner ubacio u korpu
		}
	)

	return cart_node;
}


let on_add_click = ( product_id ) =>
{
	cart.addProduct( product_id );
	update_cart();
}


let generate_product_element = product => //podrazumenvam da je product instanca klase Product
{
	const product_node = document.createElement( "div" ); //ovj nije u html
	product_node.classList.add( "product" );

	const desc = document.createElement( "div" );
	desc.innerHTML = `${product.name}`;
	desc.classList.add( "desc" );

	const add_button = document.createElement( "div" );
	add_button.classList.add( "button" );
	add_button.addEventListener( "click", () => on_add_click( product.id ) );

	product_node.appendChild( desc );
	product_node.appendChild( add_button );
	
	return product_node;
}

let init = () =>
{
	let product_display = document.querySelector( ".products" ); //html -> <div class="products"....

	console.log( product_display );
	console.log( product_list ); 

	product_list.map( product =>
		{
			let product_html_element = generate_product_element( product );
			product_display.appendChild( product_html_element );
		}
	);

	let cart_node = generate_cart_element();
	document.querySelector( ".cart_display" ).appendChild( cart_node );
}

document.addEventListener( "DOMContentLoaded", init );
